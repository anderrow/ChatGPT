const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

class Element {
  constructor(tag = 'div') {
    this.tag = tag; this.children = []; this.value = ''; this.textContent = '';
    this.listeners = {}; this.hidden = false; this.disabled = false; this.className='';
    this.classes = new Set();
    this.classList = {
      toggle: (cls, state) => state ? this.classes.add(cls) : this.classes.delete(cls),
      add: cls => this.classes.add(cls), remove: cls => this.classes.delete(cls),
    };
  }
  addEventListener(type, cb) { this.listeners[type] = cb; }
  append(...items) { this.children.push(...items); }
  replaceChildren(...items) { this.children = items; }
  click() { return this.listeners.click?.(); }
}

const ids = new Map();
function get(id) { if (!ids.has(id)) ids.set(id, new Element()); return ids.get(id); }
const calls = [];
const document = {
  getElementById: get,
  createElement: tag => new Element(tag),
  createTextNode: text => ({textContent: text}),
  createDocumentFragment: () => new Element('fragment'),
  querySelectorAll: selector => selector === '.storyBtn' ? get('stories').children : [],
};
let exported = null;
const api = {
  status: {ok:true, connected:true, userId:'5555'},
  stories: {ok:true,stories:[{id:'1000',time:'2026-10-23T18:00:00Z'}]},
  viewers: {ok:true,viewers:[{username:'alice',name:'Alice'},{username:'bob',name:'Bobby'}],total_fetched:2,new_since_last_capture:['alice'],had_previous_capture:true,captured_at:'2026-10-23T19:00:00Z',truncated:false},
  logout: {ok:true}, clear: {ok:true},
};
const window = {};
const context = {
  window, document, console, confirm:()=>true,
  StoryLensAndroid: {
    login:()=>{},
    request:(action,payload,id)=>{calls.push([action,payload]);setImmediate(()=>window.StoryLens.receive(id,api[action]));},
    saveCsv:(csv,name)=>{exported={csv,name};},
  },
  setTimeout, clearTimeout,
};
window.StoryLensAndroid = context.StoryLensAndroid;
async function drain() { await new Promise(resolve=>setTimeout(resolve,10)); }
(async () => {
  vm.runInNewContext(fs.readFileSync('app/src/main/assets/app.js','utf8'),context,{filename:'app.js'});
  await drain();
  assert.equal(get('dashboard').hidden,false,'connected dashboard shown');
  assert.equal(get('stories').children.length,1,'story listed');
  get('stories').children[0].click();
  await drain();
  assert.equal(get('total').textContent,'2','viewers count');
  assert.equal(get('newCount').textContent,'1','snapshot comparison');
  get('search').value='bob';get('search').listeners.input();
  assert.equal(get('viewerList').children.length,1,'filter displays 1 fragment');
  assert.equal(get('viewerList').children[0].children.length,1,'filter returns exactly 1 person');
  get('exportBtn').click();
  assert.ok(exported.csv.includes('"alice"') && exported.csv.includes('"bob"'),'CSV contains both');
  assert.equal(exported.name,'storylens_1000');
  get('wipe').click(); await drain();
  assert.equal(get('newCount').textContent,'–');
  get('logout').click();await drain();
  assert.equal(get('loginPanel').hidden,false,'logout reopens login');
  assert.deepEqual(calls.map(x=>x[0]),['status','stories','viewers','clear','logout']);
  console.log('UI smoke test OK: session, stories, viewers, search, export, clearing, logout');
})().catch(e=>{console.error(e);process.exitCode=1});
