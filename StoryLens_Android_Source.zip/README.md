# StoryLens Android · experimental (v0.1.0)

Aplicación Android **independiente** (no necesita PC ni backend cuando está instalada) para consultar los espectadores de **tus propias historias activas** de Instagram utilizando endpoints **no oficiales**. Interfaz en español.

> **Estado honesto**: aquí se entrega el proyecto Android listo para construir, **no un APK compilado**. Se ha validado la sintaxis del JavaScript y el manifiesto, pero no se ha podido ejecutar el build por falta del Android SDK en el entorno de creación. **No está probado con una cuenta real**. Instagram puede bloquear la autenticación dentro de un WebView o cambiar los endpoints. No se garantiza que las listas funcionen. Solo se crea una APK después de construir y probar el proyecto.

## Funcionalidad desarrollada

- Login a través de `https://www.instagram.com/accounts/login/` en un WebView **sin puente JavaScript** (StoryLens no implementa un formulario de contraseñas).
- Obtención de la sesión de Instagram a partir de cookies en el contenedor privado de la app.
- Solicitud de historias de **la cuenta que inicia sesión** y obtención paginada de sus espectadores.
- Búsqueda por usuario o nombre, comparación con captura anterior y guardado privado de listas.
- Exportación CSV desde el selector nativo de archivos Android, protección básica contra inyección de fórmulas al abrir el CSV en una hoja de cálculo.
- Desconexión eliminando cookies y opción de borrar capturas.

**No ofrece** identificación individual de reproducciones repetidas; no tiene acceso a funciones Plus de pago. El contador de nuevos espectadores entre dos capturas no significa que una persona haya reproducido de nuevo la historia.

## Cómo compilar una APK con GitHub Actions

1. Crea un repositorio **privado** de GitHub (recomendado) y sube **el contenido de esta carpeta** a la rama `main`. Debe quedar `app/` y `.github/workflows/build-apk.yml` en la raíz del repo. No subas cookies, contraseñas ni ficheros exportados.
2. En GitHub, entra en **Actions > Build StoryLens Android APK > Run workflow**. El workflow también se ejecuta al hacer un push a `main`.
3. Espera a que termine y abre la ejecución. En *Artifacts*, descarga `StoryLens-debug-apk`.
4. Descomprime y copia `app-debug.apk` a tu teléfono Android. Instálala aceptando la autorización de instalación externa solamente si confías en el código que has construido.

La compilación utiliza JDK 17, Android Gradle Plugin 8.7.3, Gradle 8.9, API 35; genera una APK **debug firmada automáticamente para pruebas**, no una versión publicada en Play Store.

## Android Studio

Abre la carpeta raíz del proyecto en Android Studio (JDK 17 / Gradle 8.9 / SDK Platform 35) y ejecuta `assembleDebug`. El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Seguridad y limitaciones importantes

- Los datos viajan directamente del dispositivo a dominios HTTPS de Instagram (`www.instagram.com` e `i.instagram.com`). Sin servidores de StoryLens, sin analítica y sin dependencias de terceros en tiempo de ejecución.
- La contraseña se escribe solo en la página web de Instagram integrada. **No significa que el WebView sea equivalente a OAuth**; la aplicación sigue teniendo acceso potencial a cookies de sesión. Audita el código antes de instalarlo y utiliza una cuenta secundaria si quieres reducir el riesgo.
- La sesión de Instagram se almacena en las cookies privadas de Android WebView; capturas de espectadores en preferencias privadas de la app. `android:allowBackup="false"` evita las copias de respaldo normales.
- La API **privada** es inestable. Se prueban por compatibilidad endpoints web/móvil; es normal recibir HTTP 401/403/429, desafíos o errores de JSON. **No hay mecanismos de evasión de bloqueos**. Se hacen solicitudes al pulsar, no en segundo plano.
- Google/Meta podría restringir una cuenta por utilizar clientes no oficiales. No está afiliada a Instagram/Meta.
- Una historia activa puede tener más espectadores de los recuperados si el servidor limita paginación, datos o acceso. La comparación entre capturas refleja solo los datos devueltos.
- Si el login WebView es rechazado por Meta, es necesario rediseñar la autenticación con un método permitido; **no** introduzcas credenciales en sitios de terceros para sortearlo.
- La app no modifica ni publica historias. No instala certificados, no pide accesibilidad, no pide permisos de almacenamiento ni captura el tráfico de otras apps.

## Archivos principales

- `app/src/main/java/com/storylens/local/MainActivity.java`: WebView de autenticación, API, exportación y controles de acceso.
- `app/src/main/assets/index.html`: interfaz.
- `app/src/main/assets/app.css`: diseño.
- `app/src/main/assets/app.js`: búsqueda, comparación y representación.
- `.github/workflows/build-apk.yml`: construcción y publicación del APK como artifact.

## Comprobaciones realizadas

- `node --check app/src/main/assets/app.js`
- Validación XML de `app/src/main/AndroidManifest.xml`
- `node tests/ui_smoke.cjs` (flujo simulado completo: sesión, historias, espectadores, filtro, CSV y salida)
- Compilación del código Java contra stubs locales (verificación parcial de sintaxis y tipos, no sustituye el Android SDK)
- Comprobación de recursos locales y estructura Gradle

Faltan: compilación real, prueba de instalación, login, consulta a endpoints contra una cuenta real y pruebas de privacidad en un teléfono físico.
