'use strict';
(function () {
  const el = id => document.getElementById(id);
  const pending = new Map();
  let serial = 0;
  let currentStory = null;
  let allViewers = [];
  let newUsers = new Set();

  window.StoryLens = {
    receive(id, data) {
      const task = pending.get(id);
      if (!task) return;
      pending.delete(id);
      if (data && data.ok) task.resolve(data);
      else task.reject(new Error((data && data.error) || 'Error desconocido'));
    }
  };

  function call(action, params={}) {
    return new Promise((resolve, reject) => {
      const id = String(++serial);
      pending.set(id, {resolve,reject});
      if (!window.StoryLensAndroid) {
        pending.delete(id);
        reject(new Error('Solo funciona en la aplicación Android'));
        return;
      }
      try { StoryLensAndroid.request(action, JSON.stringify(params), id); }
      catch (e) { pending.delete(id); reject(e); }
    });
  }

  function notice(message, success=false) {
    el('message').hidden = !message;
    el('message').textContent = message;
    el('message').className = success ? 'notice ok' : 'notice';
  }
  function busy(button, active, idle, loading) {
    button.disabled = active;
    button.textContent = active ? loading : idle;
  }
  function connected(yes, userId='') {
    el('loginPanel').hidden = yes;
    el('dashboard').hidden = !yes;
    el('connBadge').textContent = yes ? 'Conectado' : 'Sin conectar';
    el('connBadge').classList.toggle('connected', yes);
    el('welcome').textContent = yes ? 'Tus historias' : 'Tus historias';
    if (!yes) { currentStory=null; allViewers=[]; el('viewerPanel').hidden=true; el('stories').replaceChildren(); }
  }
  async function status() {
    try {
      const state = await call('status');
      connected(state.connected, state.userId);
      if (state.connected) await loadStories();
    } catch (error) { notice(error.message); }
  }
  window.onSessionChanged = status;

  async function loadStories() {
    busy(el('refresh'), true, 'Actualizar historias', 'Consultando…');
    notice('');
    el('viewerPanel').hidden = true;
    currentStory = null;
    try {
      const data = await call('stories');
      const area = el('stories'); area.replaceChildren();
      if (!data.stories.length) {
        const p = document.createElement('p');p.className='empty';
        p.textContent='No hay historias activas o el servicio no devuelve ninguna.';area.append(p);
      }
      data.stories.forEach((story,index) => {
        const b=document.createElement('button');b.type='button';b.className='storyBtn';
        const date=story.time?new Date(story.time):null;
        const friendly=date&&!Number.isNaN(date.valueOf()) ? date.toLocaleString('es-ES',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}) : 'Sin fecha';
        b.append(document.createTextNode('Historia '+(index+1)));
        const sub=document.createElement('span');sub.textContent=friendly;b.append(sub);
        b.addEventListener('click',()=>loadViewers(story,b));area.append(b);
      });
    } catch (error) { notice('No se pudieron leer tus historias: '+error.message); }
    finally { busy(el('refresh'), false, 'Actualizar historias', 'Consultando…'); }
  }
  async function loadViewers(story, button) {
    currentStory=story.id;
    allViewers=[]; newUsers=new Set();
    el('viewerPanel').hidden=false;
    el('storyInfo').textContent='Consultando espectadores…';
    el('total').textContent='…';
    el('newCount').textContent='–';
    document.querySelectorAll('.storyBtn').forEach(b=>b.classList.remove('selected'));
    button.classList.add('selected');
    renderViewers(); notice('');
    try {
      const data = await call('viewers',{id:story.id});
      if (currentStory !== story.id) return;
      allViewers = data.viewers;
      newUsers = new Set(data.new_since_last_capture.map(s=>s.toLowerCase()));
      el('storyInfo').textContent='Captura: '+new Date(data.captured_at).toLocaleString('es-ES');
      el('total').textContent=String(data.total_fetched);
      el('newCount').textContent=data.had_previous_capture ? String(data.new_since_last_capture.length) : '–';
      renderViewers();
      notice(data.truncated ? 'Se alcanzó el límite de paginación; la lista puede ser parcial.' : 'Datos capturados en este dispositivo.', true);
    } catch (error) { el('storyInfo').textContent='Error al cargar';notice('La API privada no ha devuelto espectadores: '+error.message); }
  }
  function renderViewers() {
    const query=el('search').value.toLocaleLowerCase('es');
    const list=el('viewerList');list.replaceChildren();
    const rows=allViewers.filter(u=>(u.username+' '+u.name).toLocaleLowerCase('es').includes(query));
    if (!rows.length) {
      const p=document.createElement('p');p.className='empty';
      p.textContent=allViewers.length ? 'No hay coincidencias.' : 'No hay espectadores cargados.';
      list.append(p);return;
    }
    const fragment=document.createDocumentFragment();
    for (const user of rows) {
      const row=document.createElement('div');row.className='viewer';
      const avatar=document.createElement('div');avatar.className='avatar';avatar.textContent=user.username.slice(0,1).toUpperCase();
      const info=document.createElement('div');const title=document.createElement('strong');title.textContent='@'+user.username;
      const sub=document.createElement('span');sub.textContent=user.name;info.append(title,sub);row.append(avatar,info);
      if (newUsers.has(user.username.toLowerCase())) {const tag=document.createElement('div');tag.className='newTag';tag.textContent='NUEVO';row.append(tag);}
      fragment.append(row);
    }
    list.append(fragment);
  }
  function csvCell(value) {
    let str=String(value??'');
    // Prevent spreadsheet formula injection when opening exports.
    if (/^[\s]*[=+\-@]/.test(str)) str="'"+str;
    return '"'+str.replaceAll('"','""')+'"';
  }
  function exportCsv() {
    if (!currentStory || !allViewers.length) {notice('Primero carga una historia con espectadores.');return;}
    const rows=[['usuario','nombre'],...allViewers.map(u=>[u.username,u.name])];
    const csv='\uFEFF'+rows.map(row=>row.map(csvCell).join(',')).join('\r\n');
    StoryLensAndroid.saveCsv(csv,'storylens_'+currentStory);
  }
  el('loginButton').addEventListener('click',()=>StoryLensAndroid.login());
  el('refresh').addEventListener('click',loadStories);
  el('search').addEventListener('input',renderViewers);
  el('exportBtn').addEventListener('click',exportCsv);
  el('logout').addEventListener('click',async()=>{
    if (!confirm('¿Desconectar Instagram? Las capturas locales se conservarán.'))return;
    try {await call('logout');connected(false);notice('Sesión eliminada.',true);}
    catch (err) { notice(err.message); }
  });
  el('wipe').addEventListener('click',async()=>{
    if (!confirm('¿Borrar las comparaciones guardadas en este teléfono?'))return;
    try {await call('clear');notice('Capturas borradas.',true);el('newCount').textContent='–';}
    catch (err) {notice(err.message);}
  });
  status();
})();
