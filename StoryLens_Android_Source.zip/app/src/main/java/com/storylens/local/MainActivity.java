package com.storylens.local;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Collections;
import java.util.Locale;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Standalone Android companion for viewing *your own* story viewers.
 * All HTTPS calls are to Instagram. No credentials are collected by the app:
 * the user signs in directly on instagram.com inside an isolated WebView.
 *
 * WARNING: private endpoints may change/return 401 or require challenge.
 */
public class MainActivity extends Activity {
    private final ExecutorService work = Executors.newSingleThreadExecutor();
    private final Set<String> allowedStories = Collections.synchronizedSet(new HashSet<>());
    private WebView home;
    private WebView instagram;
    private LinearLayout authPanel;
    private String accountId = "";
    private String csvPending;
    private static final int CREATE_CSV = 31;
    private static final String IG_URL = "https://www.instagram.com";
    private static final String AUTH_URL = "https://www.instagram.com/accounts/login/";

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(12, 12, 18));
        getWindow().setNavigationBarColor(Color.rgb(12, 12, 18));
        getWindow().getDecorView().setSystemUiVisibility(0);
        CookieManager.getInstance().setAcceptCookie(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(12, 12, 18));
        setContentView(root);

        authPanel = new LinearLayout(this);
        authPanel.setPadding(12, 10, 12, 10);
        Button done = new Button(this);
        done.setText("Volver a StoryLens");
        done.setAllCaps(false);
        done.setOnClickListener(v -> closeInstagram());
        authPanel.addView(done, new LinearLayout.LayoutParams(0, 52, 1));
        Button signIn = new Button(this);
        signIn.setText("Recargar login");
        signIn.setAllCaps(false);
        signIn.setOnClickListener(v -> instagram.loadUrl(AUTH_URL));
        authPanel.addView(signIn, new LinearLayout.LayoutParams(0, 52, 1));
        root.addView(authPanel);
        authPanel.setVisibility(View.GONE);

        home = new WebView(this);
        home.getSettings().setJavaScriptEnabled(true);
        home.getSettings().setDomStorageEnabled(false);
        home.getSettings().setAllowContentAccess(false);
        home.getSettings().setAllowFileAccess(false);
        home.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        home.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        home.setBackgroundColor(Color.rgb(12, 12, 18));
        // The bridge exists ONLY on this WebView, which displays a bundled local HTML file.
        home.addJavascriptInterface(new LocalBridge(), "StoryLensAndroid");
        home.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) { return true; }
        });
        root.addView(home, new LinearLayout.LayoutParams(-1, 0, 1));
        try {
            String html = readAsset("index.html");
            String css = readAsset("app.css");
            String js = readAsset("app.js");
            html = html.replace("<!-- CSS -->", "<style>" + css + "</style>")
                       .replace("<!-- JS -->", "<script>" + js + "</script>");
            home.loadDataWithBaseURL("https://appassets.androidplatform.net/", html, "text/html", "UTF-8", null);
        } catch (Exception e) { Toast.makeText(this, "Error al cargar la interfaz", Toast.LENGTH_LONG).show(); }

        instagram = new WebView(this);
        instagram.getSettings().setJavaScriptEnabled(true);
        instagram.getSettings().setDomStorageEnabled(true);
        instagram.getSettings().setAllowFileAccess(false);
        instagram.getSettings().setAllowContentAccess(false);
        instagram.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        instagram.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        instagram.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri uri = req.getUrl();
                String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
                if ("https".equals(uri.getScheme()) && (
                    host.equals("instagram.com") || host.endsWith(".instagram.com") ||
                    host.equals("facebook.com") || host.endsWith(".facebook.com") ||
                    host.equals("meta.com") || host.endsWith(".meta.com"))) return false;
                // Links outside Meta are not opened inside the login WebView.
                return true;
            }
        });
        root.addView(instagram, new LinearLayout.LayoutParams(-1, 0, 1));
        instagram.setVisibility(View.GONE);
    }

    private String readAsset(String name) throws Exception {
        try (InputStream in = getAssets().open(name); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] data = new byte[8192]; int len;
            while ((len = in.read(data)) != -1) out.write(data, 0, len);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private void openInstagram() {
        home.setVisibility(View.GONE);
        instagram.setVisibility(View.VISIBLE);
        authPanel.setVisibility(View.VISIBLE);
        instagram.loadUrl(AUTH_URL);
    }
    private void closeInstagram() {
        instagram.setVisibility(View.GONE);
        authPanel.setVisibility(View.GONE);
        home.setVisibility(View.VISIBLE);
        runOnUiThread(() -> home.evaluateJavascript("window.onSessionChanged && window.onSessionChanged()", null));
    }

    private String cookieValue(String name) {
        String cookies = CookieManager.getInstance().getCookie(IG_URL);
        if (cookies == null) return "";
        for (String pair : cookies.split(";")) {
            String[] p = pair.trim().split("=", 2);
            if (p.length == 2 && p[0].equals(name)) return p[1];
        }
        return "";
    }
    private boolean loggedIn() {
        accountId = cookieValue("ds_user_id");
        return accountId.matches("[0-9]+") && !cookieValue("sessionid").isEmpty();
    }
    private JSONObject result(boolean ok) throws Exception {
        JSONObject obj = new JSONObject();
        obj.put("ok", ok);
        return obj;
    }
    private JSONObject failure(String error) {
        JSONObject obj = new JSONObject();
        try { obj.put("ok", false).put("error", error); } catch (Exception ignored) {}
        return obj;
    }
    private void reply(String id, JSONObject data) {
        runOnUiThread(() -> home.evaluateJavascript(
            "window.StoryLens.receive(" + JSONObject.quote(id) + "," + data.toString() + ")", null));
    }

    private class LocalBridge {
        @JavascriptInterface public void login() { runOnUiThread(() -> openInstagram()); }
        @JavascriptInterface public void request(String action, String payload, String id) {
            // All access to CookieManager happens on WebView's UI thread when possible.
            runOnUiThread(() -> {
                if ("logout".equals(action)) {
                    CookieManager.getInstance().removeAllCookies(done -> {
                        CookieManager.getInstance().flush();
                        allowedStories.clear(); accountId = "";
                        try { reply(id, result(true)); } catch (Exception e) { reply(id, failure("Error de sesión")); }
                    });
                    return;
                }
                boolean connected = loggedIn();
                String cks = CookieManager.getInstance().getCookie(IG_URL);
                String csrf = cookieValue("csrftoken");
                String uid = accountId;
                if ("status".equals(action)) {
                    try { reply(id, result(true).put("connected", connected).put("username", "").put("userId", connected ? uid : "")); }
                    catch (Exception e) { reply(id, failure("Error al comprobar sesión")); }
                    return;
                }
                if (!connected) { reply(id, failure("Inicia sesión en Instagram primero.")); return; }
                work.execute(() -> {
                    try {
                        JSONObject args = new JSONObject(payload);
                        JSONObject out;
                        switch (action) {
                            case "stories": out = stories(cks, csrf, uid); break;
                            case "viewers": out = viewers(cks, csrf, uid, args.optString("id", "")); break;
                            case "clear": getPreferences(0).edit().clear().apply(); out = result(true); break;
                            default: out = failure("Acción no permitida");
                        }
                        reply(id, out);
                    } catch (Exception exc) { reply(id, failure("No se ha podido consultar Instagram: " + exc.getMessage())); }
                });
            });
        }
        @JavascriptInterface public void saveCsv(String csv, String name) {
            if (csv.length() > 2_000_000) return;
            csvPending = csv;
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("text/csv");
                    intent.putExtra(Intent.EXTRA_TITLE, name.replaceAll("[^a-zA-Z0-9_.-]", "_") + ".csv");
                    startActivityForResult(intent, CREATE_CSV);
                } catch (ActivityNotFoundException ex) { Toast.makeText(MainActivity.this, "No hay app para guardar CSV", Toast.LENGTH_LONG).show(); }
            });
        }
    }

    private JSONObject getApi(String cookies, String csrf, String path) throws Exception {
        Exception previous = null;
        for (String domain : new String[] {"https://www.instagram.com", "https://i.instagram.com"}) {
            HttpURLConnection c = null;
            try {
                URL u = new URL(domain + "/api/v1/" + path);
                c = (HttpURLConnection) u.openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(14000);
                c.setReadTimeout(16000);
                c.setRequestMethod("GET");
                c.setRequestProperty("Accept", "application/json");
                c.setRequestProperty("Cookie", cookies);
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36");
                c.setRequestProperty("X-IG-App-ID", "936619743392459");
                c.setRequestProperty("X-Requested-With", "XMLHttpRequest");
                c.setRequestProperty("X-CSRFToken", csrf);
                c.setRequestProperty("Referer", IG_URL + "/");
                int code = c.getResponseCode();
                if (code < 200 || code >= 300) {
                    previous = new Exception("HTTP " + code + " (la API privada puede estar restringida)");
                    continue;
                }
                try (InputStream in = c.getInputStream()) {
                    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192]; int n;
                    while ((n = in.read(buf)) != -1) {
                        if (bytes.size() + n > 4_000_000) throw new Exception("Respuesta de Instagram demasiado grande");
                        bytes.write(buf, 0, n);
                    }
                    JSONObject result = new JSONObject(new String(bytes.toByteArray(), StandardCharsets.UTF_8));
                    if ("fail".equals(result.optString("status"))) {
                        previous = new Exception("Instagram rechazó la consulta");
                        continue;
                    }
                    return result;
                }
            } catch (Exception e) { previous = e; }
            finally { if (c != null) c.disconnect(); }
        }
        throw previous == null ? new Exception("Error de red") : previous;
    }

    private JSONObject stories(String cookies, String csrf, String uid) throws Exception {
        JSONObject response;
        String uri = "feed/reels_media/?reel_ids=" + URLEncoder.encode(uid, "UTF-8");
        try { response = getApi(cookies, csrf, uri); }
        catch (Exception e) { response = getApi(cookies, csrf, "feed/user/" + uid + "/story/"); }
        JSONObject reel = response.optJSONObject("reel");
        if (reel == null) reel = response.optJSONObject("reels") == null ? null : response.optJSONObject("reels").optJSONObject(uid);
        // A successful HTTP status may still contain an empty/incompatible web response.
        if (reel == null) {
            try { reel = getApi(cookies, csrf, "feed/user/" + uid + "/story/").optJSONObject("reel"); }
            catch (Exception ignored) { /* Leave the result empty if Instagram rejects both paths. */ }
        }
        JSONArray data = reel == null ? null : reel.optJSONArray("items");
        JSONArray items = new JSONArray();
        Set<String> valid = new HashSet<>();
        if (data != null) for (int i = 0; i < data.length(); i++) {
            JSONObject raw = data.optJSONObject(i);
            if (raw == null) continue;
            String pk = raw.optString("pk", "");
            if (pk.isEmpty()) pk = raw.optString("id", "").split("_")[0];
            if (!pk.matches("[0-9]+")) continue;
            JSONObject one = new JSONObject();
            long ts = raw.optLong("taken_at", 0);
            one.put("id", pk);
            one.put("time", ts > 0 ? Instant.ofEpochSecond(ts).toString() : "");
            one.put("media_type", raw.optInt("media_type", 0));
            items.put(one); valid.add(pk);
        }
        allowedStories.clear(); allowedStories.addAll(valid);
        return result(true).put("stories", items);
    }

    private JSONObject viewers(String cookies, String csrf, String uid, String pk) throws Exception {
        if (!pk.matches("[0-9]+") || !allowedStories.contains(pk))
            return failure("Selecciona una de tus historias activas antes de consultar espectadores.");
        Map<String, JSONObject> dedup = new TreeMap<>();
        Set<String> cursors = new HashSet<>();
        String cursor = "";
        boolean truncated = false;
        for (int page = 0; page < 25; page++) {
            String endpoint = "media/" + pk + "/list_reel_media_viewer/?count=100";
            if (!cursor.isEmpty()) endpoint += "&max_id=" + URLEncoder.encode(cursor, "UTF-8");
            JSONObject data = getApi(cookies, csrf, endpoint);
            JSONArray users = data.optJSONArray("users");
            if (users == null) throw new Exception("La respuesta no incluye lista de espectadores");
            for (int i = 0; i < users.length(); i++) {
                JSONObject user = users.optJSONObject(i);
                if (user == null) continue;
                String handle = user.optString("username", "").trim();
                if (handle.isEmpty()) continue;
                JSONObject clean = new JSONObject().put("username", handle).put("name", user.optString("full_name", ""));
                dedup.put(handle.toLowerCase(Locale.ROOT), clean);
            }
            String next = data.optString("next_max_id", data.optString("max_id", ""));
            if (next.isEmpty()) break;
            if (!cursors.add(next)) break;
            if (page == 24) truncated = true;
            cursor = next;
            try { Thread.sleep(260); } catch (InterruptedException ex) { Thread.currentThread().interrupt(); break; }
        }
        JSONArray list = new JSONArray();
        for (JSONObject value : dedup.values()) list.put(value);
        String key = "story:" + uid + ":" + pk;
        String previous = getPreferences(0).getString(key, null);
        Set<String> oldUsers = new HashSet<>();
        if (previous != null) {
            JSONArray old = new JSONArray(previous);
            for (int i = 0; i < old.length(); i++) oldUsers.add(old.optString(i).toLowerCase(Locale.ROOT));
        }
        JSONArray newUsers = new JSONArray();
        JSONArray store = new JSONArray();
        for (JSONObject value : dedup.values()) {
            String name = value.getString("username"); store.put(name);
            if (previous != null && !oldUsers.contains(name.toLowerCase(Locale.ROOT))) newUsers.put(name);
        }
        getPreferences(0).edit().putString(key, store.toString()).apply();
        return result(true).put("id", pk).put("viewers", list).put("total_fetched", list.length())
                .put("new_since_last_capture", newUsers).put("had_previous_capture", previous != null)
                .put("captured_at", Instant.now().toString()).put("truncated", truncated);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREATE_CSV && resultCode == RESULT_OK && data != null && data.getData() != null && csvPending != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out != null) out.write(csvPending.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "CSV guardado", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "No se pudo guardar el archivo", Toast.LENGTH_LONG).show(); }
            csvPending = null;
        }
    }
    @Override public void onBackPressed() {
        if (instagram.getVisibility() == View.VISIBLE) {
            if (instagram.canGoBack()) instagram.goBack(); else closeInstagram();
        } else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        work.shutdownNow();
        home.removeJavascriptInterface("StoryLensAndroid");
        home.destroy(); instagram.destroy();
        super.onDestroy();
    }
}
